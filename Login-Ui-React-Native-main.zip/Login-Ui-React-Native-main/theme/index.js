export const themeColors = {
   bg: '#0092ff',
}   
